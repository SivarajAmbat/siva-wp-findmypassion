<?php
/**
 * Plugin Name: Career Guidance
 * Description: Qualification-based career guidance application.
 * Version: 1.0.0
 * Author: Career Guidance
 * Text Domain: career-guidance
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Plugin constants.
 */
define( 'CG_VERSION', '1.0.0' );
define( 'CG_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CG_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once CG_PLUGIN_DIR . 'includes/meta-fields.php';
require_once CG_PLUGIN_DIR . 'includes/frontend.php';
require_once CG_PLUGIN_DIR . 'includes/single-career.php';
require_once CG_PLUGIN_DIR . 'includes/admin.php';



/**
 * Register Career Custom Post Type.
 */
function cg_register_career_post_type() {

    $labels = array(
        'name'                  => 'Careers',
        'singular_name'         => 'Career',
        'menu_name'             => 'Careers',
        'name_admin_bar'        => 'Career',
        'add_new'               => 'Add New',
        'add_new_item'          => 'Add New Career',
        'new_item'              => 'New Career',
        'edit_item'             => 'Edit Career',
        'view_item'             => 'View Career',
        'view_items'            => 'View Careers',
        'search_items'          => 'Search Careers',
        'not_found'             => 'No careers found',
        'not_found_in_trash'    => 'No careers found in Trash',
        'all_items'             => 'All Careers',
        'archives'              => 'Career Archives',
        'attributes'            => 'Career Attributes',
        'insert_into_item'      => 'Insert into career',
        'uploaded_to_this_item' => 'Uploaded to this career',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_admin_bar'  => true,
        'show_in_nav_menus'  => true,

        /*
         * Enables the WordPress block editor.
         */
        'show_in_rest'       => true,

        /*
         * Individual career URLs:
         *
         * /careers/data-scientist/
         */
        'rewrite'            => array(
            'slug'       => 'careers',
            'with_front' => false,
        ),

        'has_archive'        => true,
        'hierarchical'       => false,

        /*
         * We will use the normal WordPress editor initially.
         * Structured career fields will be added in Step 2.
         */
        'supports'           => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt',
            'revisions',
            'custom-fields'
        ),

        'menu_icon'          => 'dashicons-businessperson',
        'menu_position'      => 20,

        'publicly_queryable' => true,
        'query_var'          => true,
    );

    register_post_type( 'cg_career', $args );
}

add_action( 'init', 'cg_register_career_post_type' );


/**
 * Register Qualification taxonomy.
 *
 * A career can have multiple qualifications.
 */
function cg_register_qualification_taxonomy() {

    $labels = array(
        'name'              => 'Qualifications',
        'singular_name'     => 'Qualification',
        'search_items'      => 'Search Qualifications',
        'all_items'         => 'All Qualifications',
        'parent_item'       => 'Parent Qualification',
        'parent_item_colon' => 'Parent Qualification:',
        'edit_item'         => 'Edit Qualification',
        'update_item'       => 'Update Qualification',
        'add_new_item'      => 'Add New Qualification',
        'new_item_name'     => 'New Qualification Name',
        'menu_name'         => 'Qualifications',
    );

    $args = array(
        'labels'            => $labels,
        'public'            => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,

        /*
         * Hierarchical = true makes this behave similarly
         * to WordPress Categories.
         *
         * This also gives us the option to create
         * parent/child qualification structures later.
         */
        'hierarchical'      => true,

        'rewrite'           => array(
            'slug'       => 'qualification',
            'with_front' => false,
        ),

        'query_var'         => true,
    );

    register_taxonomy(
        'cg_qualification',
        array( 'cg_career' ),
        $args
    );
}

add_action( 'init', 'cg_register_qualification_taxonomy' );


/**
 * Register Career Category taxonomy.
 *
 * Initially:
 * - Conventional
 * - Non-conventional
 */
function cg_register_career_category_taxonomy() {

    $labels = array(
        'name'              => 'Career Categories',
        'singular_name'     => 'Career Category',
        'search_items'      => 'Search Career Categories',
        'all_items'         => 'All Career Categories',
        'parent_item'       => 'Parent Career Category',
        'parent_item_colon' => 'Parent Career Category:',
        'edit_item'         => 'Edit Career Category',
        'update_item'       => 'Update Career Category',
        'add_new_item'      => 'Add New Career Category',
        'new_item_name'     => 'New Career Category Name',
        'menu_name'         => 'Career Categories',
    );

    $args = array(
        'labels'            => $labels,
        'public'            => true,
        'show_ui'           => true,
        'show_in_menu'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,

        /*
         * We want categories to be selectable,
         * but conceptually each career should have
         * one primary category.
         */
        'hierarchical'      => true,

        'rewrite'           => array(
            'slug'       => 'career-category',
            'with_front' => false,
        ),

        'query_var'         => true,
    );

    register_taxonomy(
        'cg_career_category',
        array( 'cg_career' ),
        $args
    );
}

add_action( 'init', 'cg_register_career_category_taxonomy' );


/**
 * Register Career Interest Area taxonomy.
 */
register_taxonomy(
    'cg_interest_area',
    'cg_career',
    array(
        'labels' => array(
            'name'          => 'Interested Areas',
            'singular_name' => 'Interested Area',
        ),

        'public'            => false,
        'show_ui'           => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,

        'hierarchical'      => false,

        'rewrite'           => false,

        'query_var'         => true,
    )
);




/**
 * Create the initial Career Categories.
 *
 * This runs only when the plugin is activated.
 */
function cg_create_default_career_categories() {

    $categories = array(
        'conventional' => 'Conventional',
        'non-conventional' => 'Non-conventional',
    );

    foreach ( $categories as $slug => $name ) {

        if ( ! term_exists( $slug, 'cg_career_category' ) ) {

            wp_insert_term(
                $name,
                'cg_career_category',
                array(
                    'slug' => $slug,
                )
            );
        }
    }
}


/**
 * Create initial Qualifications.
 *
 * These are only starter values.
 *
 * Administrators can add/edit/delete qualifications
 * later from WordPress Admin.
 */
function cg_create_default_qualifications() {

    $qualifications = array(
        'higher-secondary' => 'Higher Secondary',
        'under-graduate-tech' => 'Under Graduate – Tech',
        'under-graduate-non-tech' => 'Under Graduate – Non-Tech',
        'post-graduate-tech' => 'Post Graduate – Tech',
        'post-graduate-non-tech' => 'Post Graduate – Non-Tech',
        'doctorate' => 'Doctorate',
    );

    foreach ( $qualifications as $slug => $name ) {

        if ( ! term_exists( $slug, 'cg_qualification' ) ) {

            wp_insert_term(
                $name,
                'cg_qualification',
                array(
                    'slug' => $slug,
                )
            );
        }
    }
}


/**
 * Plugin activation.
 */
function cg_activate_plugin() {

    /*
     * Register everything before flushing rewrite rules.
     */
    cg_register_career_post_type();
    cg_register_qualification_taxonomy();
    cg_register_career_category_taxonomy();

    /*
     * Create initial taxonomy terms.
     */
    cg_create_default_career_categories();
    cg_create_default_qualifications();

    /*
     * Generate WordPress rewrite rules.
     */
    flush_rewrite_rules();
}

register_activation_hook( __FILE__, 'cg_activate_plugin' );


/**
 * Plugin deactivation.
 */
function cg_deactivate_plugin() {

    /*
     * We do NOT delete any careers or taxonomy data.
     */
    flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'cg_deactivate_plugin' );
