<?php
/**
 * Career Guidance - Single Career Page
 *
 * Handles the frontend display of individual careers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/**
 * Replace the normal single template for Career CPT.
 */
function cg_single_career_template( $template ) {

    if ( ! is_singular( 'cg_career' ) ) {
        return $template;
    }

    $plugin_template =
        CG_PLUGIN_DIR . 'includes/single-career-template.php';

    if ( file_exists( $plugin_template ) ) {
        return $plugin_template;
    }

    return $template;
}

add_filter(
    'single_template',
    'cg_single_career_template'
);
