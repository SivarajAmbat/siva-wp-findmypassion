<?php
/**
 * Single Career Template
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();

while ( have_posts() ) :

    the_post();

    $career_id = get_the_ID();

    /*
     * Get career category.
     */
    $categories = wp_get_post_terms(
        $career_id,
        'cg_career_category'
    );

    $category = null;

    if (
        ! empty( $categories )
        && ! is_wp_error( $categories )
    ) {
        $category = $categories[0];
    }


    /*
     * Get qualifications.
     */
    $qualifications = wp_get_post_terms(
        $career_id,
        'cg_qualification'
    );


    /*
     * Get structured career information.
     */
    $fields = cg_get_career_fields();

    $career_data = array();

    foreach ( $fields as $key => $field ) {

        $career_data[ $key ] = get_post_meta(
            $career_id,
            '_cg_' . $key,
            true
        );
    }


    /*
     * Related careers.
     */
    $related_careers = get_post_meta(
        $career_id,
        '_cg_related_careers',
        true
    );

    if ( ! is_array( $related_careers ) ) {
        $related_careers = array();
    }

    ?>

    <main class="cg-single-career">

        <div class="cg-single-career-container">

            <!-- =========================================
                 Hero
            ========================================== -->

            <header class="cg-career-hero">

                <?php if ( has_post_thumbnail() ) : ?>

                    <div class="cg-career-hero-image">

                        <?php
                        the_post_thumbnail(
                            'large',
                            array(
                                'class' => 'cg-hero-image',
                            )
                        );
                        ?>

                    </div>

                <?php endif; ?>


                <div class="cg-career-hero-content">

                    <?php if ( $category ) : ?>

                        <span
                            class="cg-career-category"
                        >
                            <?php
                            echo esc_html(
                                $category->name
                            );
                            ?>
                        </span>

                    <?php endif; ?>


                    <h1>
                        <?php the_title(); ?>
                    </h1>


                    <?php if ( has_excerpt() ) : ?>

                        <div class="cg-career-introduction">

                            <?php
                            the_excerpt();
                            ?>

                        </div>

                    <?php endif; ?>


                    <?php if ( ! empty( $qualifications ) ) : ?>

                        <div class="cg-career-qualifications">

                            <span class="cg-label">
                                Relevant qualifications
                            </span>

                            <div class="cg-qualification-tags">

                                <?php
                                foreach (
                                    $qualifications
                                    as $qualification
                                ) :
                                ?>

                                    <span
                                        class="cg-qualification-tag"
                                    >
                                        <?php
                                        echo esc_html(
                                            $qualification->name
                                        );
                                        ?>
                                    </span>

                                <?php endforeach; ?>

                            </div>

                        </div>

                    <?php endif; ?>

                </div>

            </header>


            <!-- =========================================
                 Career Content
            ========================================== -->

            <div class="cg-career-layout">

                <article
                    class="cg-career-main-content"
                >

                    <?php
                    cg_render_career_section(
                        'overview',
                        'Career Overview',
                        $career_data
                    );
                    ?>


                    <?php
                    cg_render_career_section(
                        'eligibility',
                        'Eligibility',
                        $career_data
                    );
                    ?>


                    <?php
                    cg_render_career_section(
                        'educational_pathway',
                        'Educational Pathway',
                        $career_data
                    );
                    ?>


                    <?php
                    cg_render_career_section(
                        'required_skills',
                        'Required Skills',
                        $career_data
                    );
                    ?>


                    <?php
                    cg_render_career_section(
                        'entrance_exams',
                        'Entrance Exams',
                        $career_data
                    );
                    ?>


                    <?php
                    cg_render_career_section(
                        'job_roles',
                        'Typical Job Roles',
                        $career_data
                    );
                    ?>


                    <?php
                    cg_render_career_section(
                        'salary_information',
                        'Salary Information',
                        $career_data
                    );
                    ?>


                    <?php
                    cg_render_career_section(
                        'career_growth',
                        'Career Growth',
                        $career_data
                    );
                    ?>


                    <?php
                    cg_render_career_section(
                        'recommended_courses',
                        'Recommended Courses',
                        $career_data
                    );
                    ?>


                    <!-- =====================================
                         Related Careers
                    ====================================== -->

                    <?php if ( ! empty( $related_careers ) ) : ?>

                        <section
                            class="cg-related-careers"
                        >

                            <div class="cg-section-heading">

                                <h2>
                                    Related Careers
                                </h2>

                                <p>
                                    You may also be interested
                                    in these career options.
                                </p>

                            </div>


                            <div class="cg-career-grid">

                                <?php

                                foreach (
                                    $related_careers
                                    as $related_id
                                ) :

                                    $related_post =
                                        get_post(
                                            $related_id
                                        );

                                    if (
                                        ! $related_post
                                        || $related_post->post_status
                                            !== 'publish'
                                    ) {
                                        continue;
                                    }

                                    echo cg_render_career_card(
                                        $related_post
                                    );

                                endforeach;

                                ?>

                            </div>

                        </section>

                    <?php endif; ?>

                </article>


                <!-- =====================================
                     Sidebar
                ====================================== -->

                <aside
                    class="cg-career-sidebar"
                >

                    <div
                        class="cg-career-sidebar-card"
                    >

                        <h2>
                            Explore More Careers
                        </h2>

                        <p>
                            Explore career options based
                            on your educational qualification.
                        </p>

                        <a
                            class="cg-button"
                            href="<?php echo esc_url(
                                home_url(
                                    '/find-your-career/'
                                )
                            ); ?>"
                        >
                            Explore Careers
                        </a>

                    </div>

                </aside>

            </div>

        </div>

    </main>

    <?php

endwhile;

get_footer();


/**
 * Render an individual career section.
 */
function cg_render_career_section(
    $key,
    $title,
    $career_data
) {

    if (
        ! isset( $career_data[ $key ] )
        || empty(
            trim(
                wp_strip_all_tags(
                    $career_data[ $key ]
                )
            )
        )
    ) {
        return;
    }

    ?>

    <section
        class="cg-career-content-section"
        id="cg-<?php echo esc_attr( $key ); ?>"
    >

        <h2>
            <?php echo esc_html( $title ); ?>
        </h2>

        <div class="cg-career-section-content">

            <?php
            echo wp_kses_post(
                wpautop(
                    $career_data[ $key ]
                )
            );
            ?>

        </div>

    </section>

    <?php
}
