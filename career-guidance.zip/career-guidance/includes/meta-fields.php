<?php
/**
 * Career Guidance - Career Meta Fields
 *
 * Handles structured career information and
 * career category administration.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/**
 * Career information fields.
 */
function cg_get_career_fields() {

    return array(

        'overview' => array(
            'label'       => 'Career Overview',
            'description' => 'Provide a general overview of this career.',
        ),

        'eligibility' => array(
            'label'       => 'Eligibility',
            'description' => 'Explain the educational and other eligibility requirements.',
        ),

        'educational_pathway' => array(
            'label'       => 'Educational Pathway',
            'description' => 'Explain how a student can prepare for and enter this career.',
        ),

        'required_skills' => array(
            'label'       => 'Required Skills',
            'description' => 'List the important technical, professional and soft skills.',
        ),

        'entrance_exams' => array(
            'label'       => 'Entrance Exams',
            'description' => 'Mention relevant entrance examinations, if applicable.',
        ),

        'job_roles' => array(
            'label'       => 'Typical Job Roles',
            'description' => 'Describe common job roles and positions associated with this career.',
        ),

        'salary_information' => array(
            'label'       => 'Salary Information',
            'description' => 'Provide general salary information and relevant context.',
        ),

        'career_growth' => array(
            'label'       => 'Career Growth',
            'description' => 'Explain career progression, opportunities and future growth.',
        ),

        'recommended_courses' => array(
            'label'       => 'Recommended Courses',
            'description' => 'List courses, certifications or learning paths that may be useful.',
        ),
    );
}


/**
 * Add Career Information meta box.
 */
function cg_add_career_information_meta_box() {

    add_meta_box(
        'cg_career_information',
        'Career Information',
        'cg_render_career_information_meta_box',
        'cg_career',
        'normal',
        'high'
    );
}

add_action( 'add_meta_boxes', 'cg_add_career_information_meta_box' );


/**
 * Render Career Information meta box.
 */
function cg_render_career_information_meta_box( $post ) {

    /*
     * Security nonce.
     */
    wp_nonce_field(
        'cg_save_career_information',
        'cg_career_information_nonce'
    );

    $fields = cg_get_career_fields();

    foreach ( $fields as $key => $field ) {

        $meta_key = '_cg_' . $key;

        $value = get_post_meta(
            $post->ID,
            $meta_key,
            true
        );

        ?>

        <div class="cg-field" style="margin-bottom: 30px;">

            <h3 style="margin-bottom: 6px;">
                <?php echo esc_html( $field['label'] ); ?>
            </h3>

            <p style="margin-top: 0; color: #646970;">
                <?php echo esc_html( $field['description'] ); ?>
            </p>

            <?php

            wp_editor(
                $value,
                'cg_' . $key,
                array(
                    'textarea_name' => 'cg_' . $key,
                    'textarea_rows' => 7,
                    'media_buttons' => true,
                    'teeny'         => false,
                    'quicktags'     => true,
                )
            );

            ?>

        </div>

        <?php
    }
}


/**
 * Save Career Information.
 */
function cg_save_career_information( $post_id ) {

    /*
     * Make sure this is our Career post type.
     */
    if ( get_post_type( $post_id ) !== 'cg_career' ) {
        return;
    }

    /*
     * Check whether the nonce exists.
     */
    if (
        ! isset( $_POST['cg_career_information_nonce'] )
    ) {
        return;
    }

    /*
     * Verify nonce.
     */
    if (
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['cg_career_information_nonce']
                )
            ),
            'cg_save_career_information'
        )
    ) {
        return;
    }

    /*
     * Don't save during autosave.
     */
    if (
        defined( 'DOING_AUTOSAVE' )
        && DOING_AUTOSAVE
    ) {
        return;
    }

    /*
     * Don't save revisions.
     */
    if ( wp_is_post_revision( $post_id ) ) {
        return;
    }

    /*
     * Check permissions.
     */
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    $fields = cg_get_career_fields();

    foreach ( $fields as $key => $field ) {

        $form_key = 'cg_' . $key;
        $meta_key = '_cg_' . $key;

        if ( isset( $_POST[ $form_key ] ) ) {

            /*
             * Career content is intentionally allowed
             * to contain HTML because it is entered
             * through the WordPress editor.
             */
            $value = wp_kses_post(
                wp_unslash(
                    $_POST[ $form_key ]
                )
            );

            update_post_meta(
                $post_id,
                $meta_key,
                $value
            );

        } else {

            delete_post_meta(
                $post_id,
                $meta_key
            );
        }
    }
}

add_action(
    'save_post_cg_career',
    'cg_save_career_information'
);


/**
 * Add Related Careers meta box.
 */
function cg_add_related_careers_meta_box() {

    add_meta_box(
        'cg_related_careers',
        'Related Careers',
        'cg_render_related_careers_meta_box',
        'cg_career',
        'side',
        'default'
    );
}

add_action(
    'add_meta_boxes',
    'cg_add_related_careers_meta_box'
);


/**
 * Render Related Careers.
 */
function cg_render_related_careers_meta_box( $post ) {

    $related_careers = get_post_meta(
        $post->ID,
        '_cg_related_careers',
        true
    );

    if ( ! is_array( $related_careers ) ) {
        $related_careers = array();
    }

    /*
     * Get all other careers.
     */
    $careers = get_posts(
        array(
            'post_type'      => 'cg_career',
            'post_status'    => array( 'publish', 'draft' ),
            'posts_per_page' => -1,
            'post__not_in'   => array( $post->ID ),
            'orderby'        => 'title',
            'order'          => 'ASC',
        )
    );

    wp_nonce_field(
        'cg_save_related_careers',
        'cg_related_careers_nonce'
    );

    if ( empty( $careers ) ) {

        echo '<p>No other careers are available yet.</p>';

        return;
    }

    ?>

    <p>
        Select careers that users may also be interested in.
    </p>

    <div style="max-height: 250px; overflow-y: auto;">

        <?php foreach ( $careers as $career ) : ?>

            <label
                style="
                    display:block;
                    margin-bottom:8px;
                "
            >

                <input
                    type="checkbox"
                    name="cg_related_careers[]"
                    value="<?php echo esc_attr( $career->ID ); ?>"
                    <?php
                    checked(
                        in_array(
                            $career->ID,
                            $related_careers,
                            true
                        )
                    );
                    ?>
                >

                <?php echo esc_html( $career->post_title ); ?>

            </label>

        <?php endforeach; ?>

    </div>

    <?php
}


/**
 * Save Related Careers.
 */
function cg_save_related_careers( $post_id ) {

    if ( get_post_type( $post_id ) !== 'cg_career' ) {
        return;
    }

    if (
        ! isset( $_POST['cg_related_careers_nonce'] )
    ) {
        return;
    }

    if (
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['cg_related_careers_nonce']
                )
            ),
            'cg_save_related_careers'
        )
    ) {
        return;
    }

    if (
        defined( 'DOING_AUTOSAVE' )
        && DOING_AUTOSAVE
    ) {
        return;
    }

    if ( wp_is_post_revision( $post_id ) ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    $related_careers = array();

    if (
        isset( $_POST['cg_related_careers'] )
        && is_array( $_POST['cg_related_careers'] )
    ) {

        $related_careers = array_map(
            'absint',
            wp_unslash(
                $_POST['cg_related_careers']
            )
        );

        /*
         * Remove invalid IDs and the current career.
         */
        $related_careers = array_filter(
            $related_careers,
            function ( $career_id ) use ( $post_id ) {

                return (
                    $career_id > 0
                    && $career_id !== (int) $post_id
                    && get_post_type( $career_id ) === 'cg_career'
                );
            }
        );

        $related_careers = array_values(
            array_unique( $related_careers )
        );
    }

    if ( ! empty( $related_careers ) ) {

        update_post_meta(
            $post_id,
            '_cg_related_careers',
            $related_careers
        );

    } else {

        delete_post_meta(
            $post_id,
            '_cg_related_careers'
        );
    }
}

add_action(
    'save_post_cg_career',
    'cg_save_related_careers'
);


/**
 * Replace the default Career Category taxonomy
 * metabox with a radio-button interface.
 *
 * This prevents a career from being accidentally
 * assigned to both Conventional and Non-conventional.
 */
function cg_replace_category_meta_box() {

    remove_meta_box(
        'tagsdiv-cg_career_category',
        'cg_career',
        'side'
    );

    add_meta_box(
        'cg_career_category_selector',
        'Career Category',
        'cg_render_career_category_selector',
        'cg_career',
        'side',
        'high'
    );
}

add_action(
    'add_meta_boxes',
    'cg_replace_category_meta_box',
    20
);


/**
 * Render Career Category selector.
 */
function cg_render_career_category_selector( $post ) {

    wp_nonce_field(
        'cg_save_career_category',
        'cg_career_category_nonce'
    );

    $terms = get_terms(
        array(
            'taxonomy'   => 'cg_career_category',
            'hide_empty' => false,
        )
    );

    if ( is_wp_error( $terms ) || empty( $terms ) ) {

        echo '<p>No career categories have been created.</p>';

        return;
    }

    /*
     * Get currently assigned category.
     */
    $assigned_terms = wp_get_post_terms(
        $post->ID,
        'cg_career_category',
        array(
            'fields' => 'ids',
        )
    );

    $assigned_term_id = ! empty( $assigned_terms )
        ? (int) $assigned_terms[0]
        : 0;

    ?>

    <p>
        Select the primary career category.
    </p>

    <?php foreach ( $terms as $term ) : ?>

        <label
            style="
                display:block;
                margin-bottom:8px;
            "
        >

            <input
                type="radio"
                name="cg_career_category"
                value="<?php echo esc_attr( $term->term_id ); ?>"
                <?php
                checked(
                    $assigned_term_id,
                    (int) $term->term_id
                );
                ?>
            >

            <?php echo esc_html( $term->name ); ?>

        </label>

    <?php endforeach; ?>

    <?php
}


/**
 * Save Career Category.
 */
function cg_save_career_category( $post_id ) {

    if ( get_post_type( $post_id ) !== 'cg_career' ) {
        return;
    }

    if (
        ! isset( $_POST['cg_career_category_nonce'] )
    ) {
        return;
    }

    if (
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['cg_career_category_nonce']
                )
            ),
            'cg_save_career_category'
        )
    ) {
        return;
    }

    if (
        defined( 'DOING_AUTOSAVE' )
        && DOING_AUTOSAVE
    ) {
        return;
    }

    if ( wp_is_post_revision( $post_id ) ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    /*
     * If no category was selected, remove all categories.
     */
    if ( ! isset( $_POST['cg_career_category'] ) ) {

        wp_set_post_terms(
            $post_id,
            array(),
            'cg_career_category'
        );

        return;
    }

    $term_id = absint(
        $_POST['cg_career_category']
    );

    /*
     * Verify that the term actually exists
     * in our taxonomy.
     */
    if ( ! term_exists( $term_id, 'cg_career_category' ) ) {
        return;
    }

    /*
     * Set exactly ONE category.
     */
    wp_set_post_terms(
        $post_id,
        array( $term_id ),
        'cg_career_category'
    );
}

add_action(
    'save_post_cg_career',
    'cg_save_career_category'
);
