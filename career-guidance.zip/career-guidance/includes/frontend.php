<?php
/**
 * Career Guidance - Frontend
 *
 * Handles:
 * - Qualification selection
 * - Career selection
 * - Qualification filtering
 * - Career grouping
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/**
 * Enqueue frontend CSS.
 */

/**
 * Enqueue Career Guidance frontend assets.
 *
 * CSS is loaded only on pages that use one of the
 * Career Guidance shortcodes or on individual Career pages.
 */
function cg_enqueue_frontend_assets() {

    global $post;

    if ( ! $post instanceof WP_Post ) {
        return;
    }


    /*
     * Load Career Guidance CSS when the page contains
     * any of our frontend shortcodes.
     */
    if (
        has_shortcode(
            $post->post_content,
            'cg_qualification_selector'
        )
        || has_shortcode(
            $post->post_content,
            'cg_interest_selector'
        )
        || has_shortcode(
            $post->post_content,
            'cg_career_selector'
        )
        || is_singular( 'cg_career' )
    ) {

        wp_enqueue_style(
            'cg-frontend',
            CG_PLUGIN_URL . 'assets/css/career-guidance.css',
            array(),
            CG_VERSION
        );
    }
}

add_action(
    'wp_enqueue_scripts',
    'cg_enqueue_frontend_assets'
);


/**
 * Qualification Selection Shortcode.
 *
 * Usage:
 *
 * [cg_qualification_selector]
 */
function cg_qualification_selector_shortcode() {

    $qualifications = get_terms(
        array(
            'taxonomy'   => 'cg_qualification',
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        )
    );

    if ( is_wp_error( $qualifications ) ) {
        return '';
    }

    if ( empty( $qualifications ) ) {

        return '<p>No qualifications are currently available.</p>';
    }

    ob_start();

    ?>

    <div class="cg-qualification-selector">

        <div class="cg-section-heading">

            <h2>
                What is your educational qualification?
            </h2>

            <p>
                Select your highest or current educational qualification
                to explore relevant career options.
            </p>

        </div>

        <div class="cg-qualification-grid">

            <?php foreach ( $qualifications as $qualification ) : ?>

                <?php

                /*
                 * Career selection page.
                 *
                 * We deliberately use a dedicated page URL rather
                 * than the Career CPT archive because the archive
                 * will eventually have its own purpose.
                 */
                $interest_options_url = add_query_arg(
                    'qualification',
                    $qualification->slug,
                    home_url( '/find-your-interests/'  )
                );

                ?>

                <a
                    class="cg-qualification-card"
                    href="<?php echo esc_url( $interest_options_url ); ?>"
                >

                    <span class="cg-qualification-name">
                        <?php
                        echo esc_html(
                            $qualification->name
                        );
                        ?>
                    </span>

                    <span class="cg-card-arrow">
                        →
                    </span>

                </a>

            <?php endforeach; ?>

        </div>

    </div>

    <?php

    return ob_get_clean();
}

add_shortcode(
    'cg_qualification_selector',
    'cg_qualification_selector_shortcode'
);


/**
 * Get selected qualification.
 */
function cg_get_selected_qualification() {

    if ( ! isset( $_GET['qualification'] ) ) {
        return null;
    }

    $slug = sanitize_title(
        wp_unslash(
            $_GET['qualification']
        )
    );

    if ( empty( $slug ) ) {
        return null;
    }

    $term = get_term_by(
        'slug',
        $slug,
        'cg_qualification'
    );

    if ( ! $term || is_wp_error( $term ) ) {
        return null;
    }

    return $term;
}


/**
 * Get careers matching a qualification and,
 * optionally, one or more interested areas.
 *
 * Matching rule:
 *
 * Qualification
 * AND
 * (Interest Area 1 OR Interest Area 2 OR ...)
 */
function cg_get_careers_for_qualification(
    $qualification_term,
    $interest_area_slugs = array()
) {

    if ( ! $qualification_term instanceof WP_Term ) {
        return array();
    }


    /*
     * Make sure the interest areas are always
     * treated as an array.
     */
    if ( ! is_array( $interest_area_slugs ) ) {
        $interest_area_slugs = array(
            $interest_area_slugs
        );
    }


    /*
     * Clean the submitted interest area slugs.
     */
    $interest_area_slugs = array_filter(
        array_map(
            'sanitize_title',
            $interest_area_slugs
        )
    );


    /*
     * Start with the mandatory qualification filter.
     */
    $tax_query = array(
        'relation' => 'AND',

        array(
            'taxonomy' => 'cg_qualification',
            'field'    => 'term_id',
            'terms'    => $qualification_term->term_id,
        ),
    );


    /*
     * Add Interested Areas when supplied.
     *
     * WordPress IN operator means:
     *
     * Interest 1 OR Interest 2 OR Interest 3
     */
    if ( ! empty( $interest_area_slugs ) ) {

        $tax_query[] = array(
            'taxonomy' => 'cg_interest_area',
            'field'    => 'slug',
            'terms'    => $interest_area_slugs,
            'operator' => 'IN',
        );
    }


    $query = new WP_Query(
        array(
            'post_type'              => 'cg_career',
            'post_status'            => 'publish',
            'posts_per_page'         => -1,
            'orderby'                => 'title',
            'order'                  => 'ASC',

            /*
             * Qualification AND Interested Areas.
             */
            'tax_query' => $tax_query,

            /*
             * Avoid unnecessary pagination.
             */
            'no_found_rows' => true,
        )
    );


    return $query->posts;
}


/**
 * Get careers for a qualification.
 */
// function cg_get_careers_for_qualification(
//     $qualification_term
// ) {

//     if ( ! $qualification_term instanceof WP_Term ) {
//         return array();
//     }

//     $query = new WP_Query(
//         array(
//             'post_type'              => 'cg_career',
//             'post_status'            => 'publish',
//             'posts_per_page'         => -1,
//             'orderby'                => 'title',
//             'order'                  => 'ASC',

//             /*
//              * Only careers associated with
//              * the selected qualification.
//              */
//             'tax_query' => array(
//                 array(
//                     'taxonomy' => 'cg_qualification',
//                     'field'    => 'term_id',
//                     'terms'    => $qualification_term->term_id,
//                 ),
//             ),

//             /*
//              * Avoid unnecessary pagination.
//              */
//             'no_found_rows' => true,
//         )
//     );

//     return $query->posts;
// }


/**
 * Get career category for a career.
 */
function cg_get_career_category( $career_id ) {

    $terms = wp_get_post_terms(
        $career_id,
        'cg_career_category'
    );

    if (
        empty( $terms )
        || is_wp_error( $terms )
    ) {
        return null;
    }

    return $terms[0];
}


/**
 * Render a career card.
 */
function cg_render_career_card( $career ) {

    if ( ! $career instanceof WP_Post ) {
        return '';
    }

    $career_url = get_permalink(
        $career->ID
    );

    /*
     * Prefer the excerpt for the card description.
     *
     * If no excerpt exists, generate one from
     * the main WordPress editor content.
     */
    $description = get_the_excerpt(
        $career->ID
    );

    if ( empty( $description ) ) {

        $description = wp_trim_words(
            wp_strip_all_tags(
                $career->post_content
            ),
            25
        );
    }

    ob_start();

    ?>

    <article class="cg-career-card">

        <?php if ( has_post_thumbnail( $career->ID ) ) : ?>

            <div class="cg-career-card-image">

                <a
                    href="<?php echo esc_url( $career_url ); ?>"
                >

                    <?php
                    echo get_the_post_thumbnail(
                        $career->ID,
                        'medium'
                    );
                    ?>

                </a>

            </div>

        <?php endif; ?>

        <div class="cg-career-card-content">

            <h3 class="cg-career-card-title">

                <a
                    href="<?php echo esc_url( $career_url ); ?>"
                >

                    <?php
                    echo esc_html(
                        get_the_title( $career->ID )
                    );
                    ?>

                </a>

            </h3>

            <?php if ( ! empty( $description ) ) : ?>

                <p class="cg-career-card-description">

                    <?php
                    echo esc_html(
                        $description
                    );
                    ?>

                </p>

            <?php endif; ?>

            <a
                class="cg-career-card-link"
                href="<?php echo esc_url( $career_url ); ?>"
            >
                View Career
                <span aria-hidden="true">→</span>
            </a>

        </div>

    </article>

    <?php

    return ob_get_clean();
}


/**
 * Career Selection Shortcode.
 *
 * Usage:
 *
 * [cg_career_selector]
 */
function cg_career_selector_shortcode() {

    /*
     * Get the selected qualification.
     */
    $qualification =
        cg_get_selected_qualification();


    /*
     * Get selected Interested Areas from the URL.
     */
    $interest_area_slugs = isset( $_GET['interest_areas'] )
        ? (array) $_GET['interest_areas']
        : array();


    /*
     * Sanitize the selected interest slugs.
     */
    $interest_area_slugs = array_filter(
        array_map(
            'sanitize_title',
            $interest_area_slugs
        )
    );


    /*
     * Get the actual Interested Area terms so that
     * we can display their names to the user.
     */
    $selected_interest_terms = array();

    if ( ! empty( $interest_area_slugs ) ) {

        $selected_interest_terms = get_terms(
            array(
                'taxonomy'   => 'cg_interest_area',
                'slug'       => $interest_area_slugs,
                'hide_empty' => false,
            )
        );

        if ( is_wp_error( $selected_interest_terms ) ) {
            $selected_interest_terms = array();
        }
    }


    ob_start();

    ?>


    <div class="cg-career-selector">


        <?php

        /*
         * No qualification has been selected.
         */
        if ( ! $qualification ) :

            ?>

            <div class="cg-selection-error">

                <h2>
                    Select your qualification
                </h2>

                <p>
                    Please select an educational qualification
                    before exploring careers.
                </p>

                <a
                    class="cg-button"
                    href="<?php echo esc_url(
                        home_url( '/find-your-career/' )
                    ); ?>"
                >
                    Choose Qualification
                </a>

            </div>

            <?php

            return ob_get_clean();

        endif;

        ?>


        <!--
         * User Selection Summary
         -->
        <div class="cg-selection-summary">


            <div class="cg-selected-qualification">

                <div>

                    <span class="cg-label">
                        Your qualification
                    </span>

                    <h1>
                        <?php
                        echo esc_html(
                            $qualification->name
                        );
                        ?>
                    </h1>

                </div>


                <a
                    class="cg-change-qualification"
                    href="<?php echo esc_url(
                        home_url( '/find-your-career/' )
                    ); ?>"
                >
                    Change Qualification
                </a>

            </div>


            <?php if ( ! empty( $selected_interest_terms ) ) : ?>

                <div class="cg-selected-interests">

                    <div class="cg-label">
                        Your interested areas
                    </div>


                    <div class="cg-interest-tags">

                        <?php foreach (
                            $selected_interest_terms
                            as $interest_term
                        ) : ?>

                            <span class="cg-interest-tag">

                                <?php
                                echo esc_html(
                                    $interest_term->name
                                );
                                ?>

                            </span>

                        <?php endforeach; ?>

                    </div>


                    <a
                        class="cg-change-interests"
                        href="<?php
                        echo esc_url(
                            add_query_arg(
                                'qualification',
                                $qualification->slug,
                                home_url(
                                    '/find-your-interests/'
                                )
                            )
                        );
                        ?>"
                    >
                        Change Interests
                    </a>

                </div>

            <?php endif; ?>


        </div>


        <?php

        /*
         * Get careers using:
         *
         * Qualification
         * AND
         * (Interest Area 1 OR Interest Area 2 ...)
         */
        $careers =
            cg_get_careers_for_qualification(
                $qualification,
                $interest_area_slugs
            );


        /*
         * No careers.
         */
        if ( empty( $careers ) ) :

            ?>

            <div class="cg-no-careers">

                <h2>
                    We couldn't find matching careers
                </h2>

                <?php if ( ! empty( $selected_interest_terms ) ) : ?>

                    <p>
                        We don't currently have careers matching
                        your qualification and selected areas of interest.
                    </p>

                <?php else : ?>

                    <p>
                        We don't currently have careers mapped
                        to this qualification.
                    </p>

                <?php endif; ?>


                <div class="cg-no-careers-actions">

                    <a
                        class="cg-secondary-button"
                        href="<?php echo esc_url(
                            home_url(
                                '/find-your-career/'
                            )
                        ); ?>"
                    >
                        Change Qualification
                    </a>


                    <a
                        class="cg-button"
                        href="<?php
                        echo esc_url(
                            add_query_arg(
                                'qualification',
                                $qualification->slug,
                                home_url(
                                    '/find-your-interests/'
                                )
                            )
                        );
                        ?>"
                    >
                        Change Interests
                    </a>

                </div>

            </div>

            <?php

            return ob_get_clean();

        endif;


        /*
         * Separate careers into the two categories.
         */
        $conventional = array();
        $non_conventional = array();
        $uncategorized = array();


        foreach ( $careers as $career ) {

            $category =
                cg_get_career_category(
                    $career->ID
                );


            if ( ! $category ) {

                $uncategorized[] = $career;

                continue;
            }


            if (
                $category->slug ===
                'conventional'
            ) {

                $conventional[] = $career;

            } elseif (
                $category->slug ===
                'non-conventional'
            ) {

                $non_conventional[] = $career;

            } else {

                $uncategorized[] = $career;
            }
        }

        ?>


        <!--
         * Career Results Heading
         -->
        <div class="cg-results-heading">

            <h2>
                Career Options
            </h2>

            <p>
                Explore careers that match your qualification
                and areas of interest.
            </p>

        </div>


        <?php if ( ! empty( $conventional ) ) : ?>

            <section
                class="cg-career-section cg-conventional-section"
            >

                <div class="cg-section-heading">

                    <h2>
                        Conventional Careers
                    </h2>

                    <p>
                        Established career paths associated
                        with your selection.
                    </p>

                </div>


                <div class="cg-career-grid">

                    <?php foreach (
                        $conventional
                        as $career
                    ) : ?>

                        <?php

                        echo cg_render_career_card(
                            $career
                        );

                        ?>

                    <?php endforeach; ?>

                </div>

            </section>

        <?php endif; ?>


        <?php if ( ! empty( $non_conventional ) ) : ?>

            <section
                class="cg-career-section cg-non-conventional-section"
            >

                <div class="cg-section-heading">

                    <h2>
                        Non-conventional Careers
                    </h2>

                    <p>
                        Emerging, specialized or less traditional
                        career paths associated with your selection.
                    </p>

                </div>


                <div class="cg-career-grid">

                    <?php foreach (
                        $non_conventional
                        as $career
                    ) : ?>

                        <?php

                        echo cg_render_career_card(
                            $career
                        );

                        ?>

                    <?php endforeach; ?>

                </div>

            </section>

        <?php endif; ?>


        <?php if ( ! empty( $uncategorized ) ) : ?>

            <section
                class="cg-career-section cg-other-section"
            >

                <div class="cg-section-heading">

                    <h2>
                        Other Careers
                    </h2>

                    <p>
                        These careers have not yet been assigned
                        to a primary category.
                    </p>

                </div>


                <div class="cg-career-grid">

                    <?php foreach (
                        $uncategorized
                        as $career
                    ) : ?>

                        <?php

                        echo cg_render_career_card(
                            $career
                        );

                        ?>

                    <?php endforeach; ?>

                </div>

            </section>

        <?php endif; ?>


    </div>

    <?php


    return ob_get_clean();
}


add_shortcode(
    'cg_career_selector',
    'cg_career_selector_shortcode'
);


/**
 * Interested Area Selector
 */
function cg_interest_selector_shortcode() {

    /*
     * Get the qualification selected on the
     * previous screen.
     */
    $qualification = isset( $_GET['qualification'] )
        ? sanitize_title(
            wp_unslash(
                $_GET['qualification']
            )
        )
        : '';


    /*
     * Get previously selected interest areas.
     *
     * This allows the selections to remain checked
     * if the user reloads the page or comes back to it.
     */
    $selected_interest_areas = isset( $_GET['interest_areas'] )
        ? (array) $_GET['interest_areas']
        : array();


    /*
     * Sanitize selected interest areas.
     */
    $selected_interest_areas = array_filter(
        array_map(
            'sanitize_title',
            $selected_interest_areas
        )
    );


    /*
     * Get all Interested Area terms.
     */
    $interest_areas = get_terms(
        array(
            'taxonomy'   => 'cg_interest_area',
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        )
    );


    if (
        is_wp_error( $interest_areas )
        || empty( $interest_areas )
    ) {

        return '<p>No interested areas are currently available.</p>';
    }


    ob_start();

    ?>

    <div class="cg-interest-selector">


        <div class="cg-section-heading">

            <h2>
                What areas are you interested in?
            </h2>

            <p>
                Select one or more areas that interest you.
            </p>

        </div>


        <form
            method="get"
            action="<?php echo esc_url(
                home_url( '/career-options/' )
            ); ?>"
            class="cg-interest-form"
        >


            <?php if ( ! empty( $qualification ) ) : ?>

                <input
                    type="hidden"
                    name="qualification"
                    value="<?php echo esc_attr(
                        $qualification
                    ); ?>"
                >

            <?php endif; ?>


            <div class="cg-interest-grid">


                <?php foreach ( $interest_areas as $interest_area ) : ?>

                    <?php

                    $is_selected = in_array(
                        $interest_area->slug,
                        $selected_interest_areas,
                        true
                    );

                    ?>


                    <label
                        class="cg-interest-card<?php echo $is_selected ? ' is-selected' : ''; ?>"
                    >


                        <input
                            type="checkbox"
                            name="interest_areas[]"
                            value="<?php echo esc_attr(
                                $interest_area->slug
                            ); ?>"
                            <?php checked(
                                $is_selected
                            ); ?>
                        >


                        <span class="cg-interest-card-content">

                            <span class="cg-interest-card-name">

                                <?php
                                echo esc_html(
                                    $interest_area->name
                                );
                                ?>

                            </span>


                            <span
                                class="cg-interest-card-check"
                                aria-hidden="true"
                            >
                                ✓
                            </span>

                        </span>


                    </label>

                <?php endforeach; ?>


            </div>


            <div class="cg-interest-actions">


                <a
                    class="cg-secondary-button"
                    href="<?php echo esc_url(
                        home_url( '/find-your-career/' )
                    ); ?>"
                >
                    ← Change Qualification
                </a>


                <button
                    type="submit"
                    class="cg-button"
                    id="cg-interest-continue"
                    disabled
                >
                    Continue
                </button>


            </div>


        </form>


    </div>


    <script>
    document.addEventListener(
        'DOMContentLoaded',
        function () {

            const form =
                document.querySelector(
                    '.cg-interest-form'
                );

            if ( ! form ) {
                return;
            }


            const checkboxes =
                form.querySelectorAll(
                    'input[name="interest_areas[]"]'
                );


            const continueButton =
                document.getElementById(
                    'cg-interest-continue'
                );


            function updateInterestState() {

                let selectedCount = 0;


                checkboxes.forEach(
                    function (checkbox) {

                        const card =
                            checkbox.closest(
                                '.cg-interest-card'
                            );


                        if ( checkbox.checked ) {

                            selectedCount++;

                            card.classList.add(
                                'is-selected'
                            );

                        } else {

                            card.classList.remove(
                                'is-selected'
                            );

                        }

                    }
                );


                continueButton.disabled =
                    selectedCount === 0;

            }


            checkboxes.forEach(
                function (checkbox) {

                    checkbox.addEventListener(
                        'change',
                        updateInterestState
                    );

                }
            );


            updateInterestState();

        }
    );
    </script>


    <?php

    return ob_get_clean();
}


add_shortcode(
    'cg_interest_selector',
    'cg_interest_selector_shortcode'
);
