<?php
/**
 * Career Guidance - Admin functionality
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/**
 * Add custom columns to Career admin list.
 */
function cg_career_admin_columns( $columns ) {

    $new_columns = array();

    foreach ( $columns as $key => $label ) {

        $new_columns[ $key ] = $label;

        if ( 'title' === $key ) {

            $new_columns['cg_category'] =
                'Category';

            $new_columns['cg_qualifications'] =
                'Qualifications';
        }
    }

    return $new_columns;
}

add_filter(
    'manage_cg_career_posts_columns',
    'cg_career_admin_columns'
);


/**
 * Populate custom Career columns.
 */
function cg_career_admin_column_content(
    $column,
    $post_id
) {

    if ( 'cg_category' === $column ) {

        $terms = wp_get_post_terms(
            $post_id,
            'cg_career_category'
        );

        if (
            ! empty( $terms )
            && ! is_wp_error( $terms )
        ) {

            $names = array();

            foreach ( $terms as $term ) {
                $names[] = $term->name;
            }

            echo esc_html(
                implode( ', ', $names )
            );

        } else {

            echo '<span style="color:#b32d2e;">Not assigned</span>';
        }

        return;
    }


    if ( 'cg_qualifications' === $column ) {

        $terms = wp_get_post_terms(
            $post_id,
            'cg_qualification'
        );

        if (
            ! empty( $terms )
            && ! is_wp_error( $terms )
        ) {

            $names = array();

            foreach ( $terms as $term ) {
                $names[] = $term->name;
            }

            echo esc_html(
                implode( ', ', $names )
            );

        } else {

            echo '<span style="color:#b32d2e;">Not assigned</span>';
        }

        return;
    }
}

add_action(
    'manage_cg_career_posts_custom_column',
    'cg_career_admin_column_content',
    10,
    2
);

/**
 * Add taxonomy filters to Career admin list.
 */
function cg_career_admin_filters() {

    global $typenow;

    if ( 'cg_career' !== $typenow ) {
        return;
    }

    $taxonomies = array(
        'cg_qualification',
        'cg_career_category',
    );

    foreach ( $taxonomies as $taxonomy ) {

        $taxonomy_object =
            get_taxonomy( $taxonomy );

        if ( ! $taxonomy_object ) {
            continue;
        }

        $selected =
            isset( $_GET[ $taxonomy ] )
                ? sanitize_text_field(
                    wp_unslash(
                        $_GET[ $taxonomy ]
                    )
                )
                : '';

        wp_dropdown_categories(
            array(
                'show_option_all' =>
                    'All ' . $taxonomy_object->label,

                'taxonomy'        => $taxonomy,

                'name'            => $taxonomy,

                'orderby'         => 'name',

                'selected'        => $selected,

                'hierarchical'    => true,

                'depth'           => 2,

                'hide_empty'      => false,
            )
        );
    }
}

add_action(
    'restrict_manage_posts',
    'cg_career_admin_filters'
);

/**
 * Make Career admin columns sortable.
 */
function cg_career_sortable_columns( $columns ) {

    $columns['cg_category'] =
        'cg_category';

    $columns['cg_qualifications'] =
        'cg_qualifications';

    return $columns;
}

add_filter(
    'manage_edit-cg_career_sortable_columns',
    'cg_career_sortable_columns'
);

/**
 * Show Career data completeness warning.
 */
function cg_career_admin_notice() {

    global $post;

    if (
        ! $post instanceof WP_Post
        || 'cg_career' !== $post->post_type
    ) {
        return;
    }

    if (
        ! current_user_can( 'edit_post', $post->ID )
    ) {
        return;
    }

    $messages = array();


    /*
     * Check qualifications.
     */
    $qualifications = wp_get_post_terms(
        $post->ID,
        'cg_qualification'
    );

    if (
        empty( $qualifications )
        || is_wp_error( $qualifications )
    ) {

        $messages[] =
            'No educational qualification has been assigned.';
    }


    /*
     * Check category.
     */
    $categories = wp_get_post_terms(
        $post->ID,
        'cg_career_category'
    );

    if (
        empty( $categories )
        || is_wp_error( $categories )
    ) {

        $messages[] =
            'No career category has been assigned.';
    }


    /*
     * Check overview.
     */
    $overview = get_post_meta(
        $post->ID,
        '_cg_overview',
        true
    );

    if (
        empty(
            trim(
                wp_strip_all_tags(
                    $overview
                )
            )
        )
    ) {

        $messages[] =
            'Career Overview is empty.';
    }


    if ( empty( $messages ) ) {
        return;
    }

    ?>

    <div
        class="notice notice-warning"
        style="padding-bottom:10px;"
    >

        <p>
            <strong>
                Career information needs attention:
            </strong>
        </p>

        <ul>

            <?php foreach ( $messages as $message ) : ?>

                <li>
                    <?php
                    echo esc_html(
                        $message
                    );
                    ?>
                </li>

            <?php endforeach; ?>

        </ul>

    </div>

    <?php
}

add_action(
    'admin_notices',
    'cg_career_admin_notice'
);
